// DOM Elements
const noteInput = document.getElementById("noteInput");
const addNoteBtn = document.getElementById("addNoteBtn");
const notesContainer = document.getElementById("notesContainer");

let editingIndex = null; // To track the note being edited

// Retrieve notes from localStorage
function getNotes() {
  return JSON.parse(localStorage.getItem("notes")) || [];
}

// Save notes to localStorage
function saveNotes(notes) {
  localStorage.setItem("notes", JSON.stringify(notes));
}

// Render notes to the DOM
function renderNotes() {
  notesContainer.innerHTML = ""; // Clear the container
  const notes = getNotes();

  notes.forEach((note, index) => {
    const noteDiv = document.createElement("div");
    noteDiv.classList.add("note");

    // Note content
    const noteText = document.createElement("p");
    noteText.textContent = note.text;

    // Timestamp
    const timestamp = document.createElement("span");
    timestamp.classList.add("timestamp");
    timestamp.textContent = `Last edited: ${note.date}`;

    // Action Buttons
    const actionsDiv = document.createElement("div");
    actionsDiv.classList.add("actions");

    const deleteBtn = document.createElement("button");
    deleteBtn.classList.add("delete");
    deleteBtn.textContent = "Delete";
    deleteBtn.onclick = () => deleteNote(index);

    const editBtn = document.createElement("button");
    editBtn.classList.add("edit");
    editBtn.textContent = "Edit";
    editBtn.onclick = () => startEditing(index);

    actionsDiv.appendChild(editBtn);
    actionsDiv.appendChild(deleteBtn);

    noteDiv.appendChild(noteText);
    noteDiv.appendChild(timestamp);
    noteDiv.appendChild(actionsDiv);

    notesContainer.appendChild(noteDiv);
  });
}

// Add or Edit a Note
addNoteBtn.addEventListener("click", () => {
  const noteText = noteInput.value.trim();
  if (noteText === "") return;

  const notes = getNotes();
  const now = new Date();
  const timestamp = now.toLocaleString();

  if (editingIndex !== null) {
    // Edit existing note
    notes[editingIndex] = { text: noteText, date: timestamp };
    editingIndex = null;
    addNoteBtn.textContent = "Add Note"; // Reset button text
  } else {
    // Add new note
    notes.push({ text: noteText, date: timestamp });
  }

  saveNotes(notes);
  noteInput.value = ""; // Clear input field
  renderNotes();
});

// Delete a Note
function deleteNote(index) {
  const notes = getNotes();
  notes.splice(index, 1); // Remove note by index
  saveNotes(notes);
  renderNotes();
}

// Start Editing a Note
function startEditing(index) {
  const notes = getNotes();
  const note = notes[index];

  noteInput.value = note.text; // Populate the textarea with the note content
  editingIndex = index; // Track which note is being edited
  addNoteBtn.textContent = "Update Note"; // Change button text
}

// Initialize App
document.addEventListener("DOMContentLoaded", renderNotes);
